#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

void DebugPrintA(const char *format, ...)
{
	va_list args;
	va_start(args, format);
	char buffer[512];
	_vsnprintf_s(buffer, sizeof(buffer), _TRUNCATE, format, args);
	OutputDebugStringA(buffer);
}

void DebugPrintW(const WCHAR *format, ...)
{
	va_list args;
	va_start(args, format);
	WCHAR buffer[512];
	_vsnwprintf_s(buffer, sizeof(buffer) / sizeof(WCHAR), _TRUNCATE, format, args);
	OutputDebugStringW(buffer);
}
