//SBIE DLL API - https://www.sandboxie.com/index.php?SBIE_DLL_API

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "Debug.h"
#include "Hook.h"
#include "Settings.h"
#include "Sandboxie.h"

SbieApi_EnumBoxes_ SbieApi_EnumBoxes;
SbieApi_QueryBoxPath_ SbieApi_QueryBoxPath;
SbieApi_QueryProcessPath_ SbieApi_QueryProcessPath;
SbieApi_EnumProcessEx_ SbieApi_EnumProcessEx;
SbieApi_QueryProcess_ SbieApi_QueryProcess;
SbieDll_KillOne_ SbieDll_KillOne;
SbieDll_KillAll_ SbieDll_KillAll;
SbieApi_QueryConf_ SbieApi_QueryConf;
SbieDll_UpdateConf_ SbieDll_UpdateConf;
SbieApi_ReloadConf_ SbieApi_ReloadConf;
SbieDll_Hook_ SbieDll_Hook;
SbieDll_RegisterDllCallback_ SbieDll_RegisterDllCallback;
SbieApi_GetHomePath_ SbieApi_GetHomePath;

__declspec(dllexport) void __stdcall InjectDllMain(HINSTANCE hSbieDll, ULONG_PTR UnusedParameter)
{
	SbieApi_EnumBoxes = (SbieApi_EnumBoxes_)GetProcAddress(hSbieDll, "SbieApi_EnumBoxes");
	SbieApi_QueryBoxPath = (SbieApi_QueryBoxPath_)GetProcAddress(hSbieDll, "SbieApi_QueryBoxPath");
	SbieApi_QueryProcessPath = (SbieApi_QueryProcessPath_)GetProcAddress(hSbieDll, "SbieApi_QueryProcessPath");
	SbieApi_EnumProcessEx = (SbieApi_EnumProcessEx_)GetProcAddress(hSbieDll, "SbieApi_EnumProcessEx");
	SbieApi_QueryProcess = (SbieApi_QueryProcess_)GetProcAddress(hSbieDll, "SbieApi_QueryProcess");
	SbieDll_KillOne = (SbieDll_KillOne_)GetProcAddress(hSbieDll, "SbieDll_KillOne");
	SbieDll_KillAll = (SbieDll_KillAll_)GetProcAddress(hSbieDll, "SbieDll_KillAll");
	SbieApi_QueryConf = (SbieApi_QueryConf_)GetProcAddress(hSbieDll, "SbieApi_QueryConf");
	SbieDll_UpdateConf = (SbieDll_UpdateConf_)GetProcAddress(hSbieDll, "SbieDll_UpdateConf");
	SbieApi_ReloadConf = (SbieApi_ReloadConf_)GetProcAddress(hSbieDll, "SbieApi_ReloadConf");
	SbieDll_Hook = (SbieDll_Hook_)GetProcAddress(hSbieDll, "SbieDll_Hook");
	SbieDll_RegisterDllCallback = (SbieDll_RegisterDllCallback_)GetProcAddress(hSbieDll, "SbieDll_RegisterDllCallback");
	SbieApi_GetHomePath = (SbieApi_GetHomePath_)GetProcAddress(hSbieDll, "SbieApi_GetHomePath");

	if (SbieDll_Hook)
	{
		SettingsLoad();
		HookInit();
	}
}
