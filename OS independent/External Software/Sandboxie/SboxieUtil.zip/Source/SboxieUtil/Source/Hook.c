#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Shellapi.h>
#include "Debug.h"
#include "Hook.h"
#include "Sandboxie.h"
#include "Shell32.h"
#include "Advapi32.h"
#include "User32.h"
#include "Kernel32.h"

#define HOOK(A) \
	proc = GetProcAddress(hMod, #A); \
	if (proc) Real ## A = (Real ## A ## _)SbieDll_Hook(#A,proc,Fake ## A);

void HookInit()
{
	FARPROC proc;
	HMODULE hMod;
	
	hMod = LoadLibrary("Shell32.dll");
	if (hMod)
	{
		HOOK(ShellExecuteExW);
		FreeLibrary(hMod);
	}
	
	hMod = LoadLibrary("Advapi32.dll");
	if (hMod)
	{
		HOOK(CheckTokenMembership);
		FreeLibrary(hMod);
	}

	hMod = LoadLibrary("User32.dll");
	if (hMod)
	{
		HOOK(AddClipboardFormatListener);
		HOOK(ChangeClipboardChain);
		HOOK(CloseClipboard);
		HOOK(CountClipboardFormats);
		HOOK(EmptyClipboard);
		HOOK(EnumClipboardFormats);
		HOOK(GetClipboardData);
		HOOK(GetClipboardFormatNameA);
		HOOK(GetClipboardFormatNameW);
		HOOK(GetClipboardOwner);
		HOOK(GetClipboardSequenceNumber);
		HOOK(GetClipboardViewer);
		HOOK(GetOpenClipboardWindow);
		HOOK(GetPriorityClipboardFormat);
		HOOK(IsClipboardFormatAvailable);
		HOOK(OpenClipboard);
		HOOK(RegisterClipboardFormatA);
		HOOK(RegisterClipboardFormatW);
		HOOK(RemoveClipboardFormatListener);
		HOOK(SetClipboardData);
		HOOK(SetClipboardViewer);
		FreeLibrary(hMod);
	}

	FARPROC cpi = GetProcAddress(GetModuleHandle("Kernelbase.dll"), "CreateProcessInternalW");
	if (!cpi)
		cpi = GetProcAddress(GetModuleHandle("Kernel32.dll"), "CreateProcessInternalW");
	RealCreateProcessInternalW = 
		(RealCreateProcessInternalW_)SbieDll_Hook("CreateProcessInternalW", cpi, FakeCreateProcessInternalW);
}
