#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Shlwapi.h>
#include <Shellapi.h>
#include "Debug.h"
#include "Settings.h"
#include "Kernel32.h"

RealCreateProcessInternalW_ RealCreateProcessInternalW;

#pragma region Process and Thread Functions

BOOL WINAPI FakeCreateProcessInternalW(
	HANDLE hToken, LPCWSTR lpApplicationName, LPWSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes,
	LPSECURITY_ATTRIBUTES lpThreadAttributes, BOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment,
	LPCWSTR lpCurrentDirectory, LPSTARTUPINFOW lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation,
	PHANDLE hNewToken)
{
	if (StartRun_RestrictionsEnabled)
	{
		WCHAR fileName[MAX_PATH] = L"";
		
		if (lpApplicationName)
		{
			wcscpy_s(fileName, MAX_PATH, PathFindFileNameW(lpApplicationName));
		}
		else if (lpCommandLine)
		{
			if (wcschr(lpCommandLine, L'"'))
			{
				int argCount;
				WCHAR **argList = CommandLineToArgvW(lpCommandLine, &argCount);
				if (argList)
				{
					if (argCount > 0)
						wcscpy_s(fileName, MAX_PATH, PathFindFileNameW(argList[0]));

					LocalFree(argList);
				}
			}
			else
				wcscpy_s(fileName, MAX_PATH, PathFindFileNameW(lpCommandLine));
		}
		
		if (!ListContains(SANDBOXIE_EXECUTABLES, fileName, L",") && !ListContains(StartRun_Exceptions, fileName, L","))
		{
			PUBLIC_DEBUG(L"Program cannot start due to restrictions '%s'", fileName);
			return FALSE;
		}
	}

	return RealCreateProcessInternalW(
		hToken, lpApplicationName, lpCommandLine, lpProcessAttributes, lpThreadAttributes, bInheritHandles,
		dwCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo, lpProcessInformation, hNewToken);
}

#pragma endregion
