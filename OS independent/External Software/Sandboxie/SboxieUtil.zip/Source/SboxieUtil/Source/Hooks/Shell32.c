#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Shellapi.h>
#include "Debug.h"
#include "Shell32.h"
#include "Settings.h"

RealShellExecuteExW_ RealShellExecuteExW;

#pragma region Shell Functions

BOOL WINAPI FakeShellExecuteExW(SHELLEXECUTEINFOW *pExecInfo)
{
	if (NoAdmin_HookShellExecute)
	{
		if (pExecInfo->lpVerb && _wcsicmp(pExecInfo->lpVerb, L"runas") == 0)
			pExecInfo->lpVerb = L"open";
	}

	return RealShellExecuteExW(pExecInfo);
}

#pragma endregion

