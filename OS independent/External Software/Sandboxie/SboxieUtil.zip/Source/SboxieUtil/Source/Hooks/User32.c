#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "Debug.h"
#include "User32.h"
#include "Settings.h"

RealAddClipboardFormatListener_ RealAddClipboardFormatListener;
RealChangeClipboardChain_ RealChangeClipboardChain;
RealCloseClipboard_ RealCloseClipboard;
RealCountClipboardFormats_ RealCountClipboardFormats;
RealEmptyClipboard_ RealEmptyClipboard;
RealEnumClipboardFormats_ RealEnumClipboardFormats;
RealGetClipboardData_ RealGetClipboardData;
RealGetClipboardFormatNameA_ RealGetClipboardFormatNameA;
RealGetClipboardFormatNameW_ RealGetClipboardFormatNameW;
RealGetClipboardOwner_ RealGetClipboardOwner;
RealGetClipboardSequenceNumber_ RealGetClipboardSequenceNumber;
RealGetClipboardViewer_ RealGetClipboardViewer;
RealGetOpenClipboardWindow_ RealGetOpenClipboardWindow;
RealGetPriorityClipboardFormat_ RealGetPriorityClipboardFormat;
RealGetUpdatedClipboardFormats_ RealGetUpdatedClipboardFormats;
RealIsClipboardFormatAvailable_ RealIsClipboardFormatAvailable;
RealOpenClipboard_ RealOpenClipboard;
RealRegisterClipboardFormatA_ RealRegisterClipboardFormatA;
RealRegisterClipboardFormatW_ RealRegisterClipboardFormatW;
RealRemoveClipboardFormatListener_ RealRemoveClipboardFormatListener;
RealSetClipboardData_ RealSetClipboardData;
RealSetClipboardViewer_ RealSetClipboardViewer;

#pragma region Clipboard Functions

BOOL WINAPI FakeAddClipboardFormatListener(HWND hwnd)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return TRUE;

	return RealAddClipboardFormatListener(hwnd);
}

BOOL WINAPI FakeChangeClipboardChain(HWND hWndRemove, HWND hWndNewNext)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return TRUE;

	return RealChangeClipboardChain(hWndRemove, hWndNewNext);
}

BOOL WINAPI FakeCloseClipboard(void)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return TRUE;

	return RealCloseClipboard();
}

int WINAPI FakeCountClipboardFormats(void)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealCountClipboardFormats();
}

BOOL WINAPI FakeEmptyClipboard(void)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL || 
		Clipboard_Access == CLIPBOARD_ACCESS_BLOCK || 
		Clipboard_Access == CLIPBOARD_ACCESS_READ)
		return TRUE;

	return RealEmptyClipboard();
}

UINT WINAPI FakeEnumClipboardFormats(UINT format)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealEnumClipboardFormats(format);
}

HANDLE WINAPI FakeGetClipboardData(UINT uFormat)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL || 
		Clipboard_Access == CLIPBOARD_ACCESS_BLOCK || 
		Clipboard_Access == CLIPBOARD_ACCESS_WRITE)
		return NULL;

	return RealGetClipboardData(uFormat);
}

int WINAPI FakeGetClipboardFormatNameA(UINT format, LPTSTR lpszFormatName, int cchMaxCount)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealGetClipboardFormatNameA(format, lpszFormatName, cchMaxCount);
}

int WINAPI FakeGetClipboardFormatNameW(UINT format, LPWSTR lpszFormatName, int cchMaxCount)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealGetClipboardFormatNameW(format, lpszFormatName, cchMaxCount);
}

HWND WINAPI FakeGetClipboardOwner(void)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return NULL;

	return RealGetClipboardOwner();
}

DWORD WINAPI FakeGetClipboardSequenceNumber(void)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealGetClipboardSequenceNumber();
}

HWND WINAPI FakeGetClipboardViewer(void)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return NULL;

	return RealGetClipboardViewer();
}

HWND WINAPI FakeGetOpenClipboardWindow(void)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return NULL;

	return RealGetOpenClipboardWindow();
}

int WINAPI FakeGetPriorityClipboardFormat(UINT *paFormatPriorityList, int cFormats)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealGetPriorityClipboardFormat(paFormatPriorityList, cFormats);
}

BOOL WINAPI FakeGetUpdatedClipboardFormats(PUINT lpuiFormats, UINT cFormats, PUINT pcFormatsOut)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return FALSE;

	return RealGetUpdatedClipboardFormats(lpuiFormats, cFormats, pcFormatsOut);
}

BOOL WINAPI FakeIsClipboardFormatAvailable(UINT format)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return FALSE;

	return RealIsClipboardFormatAvailable(format);
}

BOOL WINAPI FakeOpenClipboard(HWND hWndNewOwner)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return TRUE;

	return RealOpenClipboard(hWndNewOwner);
}

UINT WINAPI FakeRegisterClipboardFormatA(LPCTSTR lpszFormat)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealRegisterClipboardFormatA(lpszFormat);
}

UINT WINAPI FakeRegisterClipboardFormatW(LPCWSTR lpszFormat)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return 0;

	return RealRegisterClipboardFormatW(lpszFormat);
}

BOOL WINAPI FakeRemoveClipboardFormatListener(HWND hwnd)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return TRUE;

	return RealRemoveClipboardFormatListener(hwnd);
}

HANDLE WINAPI FakeSetClipboardData(UINT uFormat, HANDLE hMem)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL || 
		Clipboard_Access == CLIPBOARD_ACCESS_BLOCK || 
		Clipboard_Access == CLIPBOARD_ACCESS_READ)
		return NULL;

	return RealSetClipboardData(uFormat, hMem);
}

HWND WINAPI FakeSetClipboardViewer(HWND hWndNewViewer)
{
	if (Clipboard_Access == CLIPBOARD_ACCESS_BLOCK_ALL)
		return NULL;

	return RealSetClipboardViewer(hWndNewViewer);
}

#pragma endregion

