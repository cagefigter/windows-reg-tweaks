#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "Debug.h"
#include "Advapi32.h"
#include "Settings.h"

RealCheckTokenMembership_ RealCheckTokenMembership;

#pragma region Authorization Functions

BOOL WINAPI FakeCheckTokenMembership(HANDLE TokenHandle, PSID SidToCheck, PBOOL IsMember)
{
	if (NoAdmin_HookCheckTokenMembership)
	{
		//Should probably add some more code here, but will get the job done for inno setup installers for now.
		*IsMember = TRUE;
		return TRUE;
	}
	
	return RealCheckTokenMembership(TokenHandle, SidToCheck, IsMember);
}

#pragma endregion

