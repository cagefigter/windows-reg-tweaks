#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Shlwapi.h>
#include <stdio.h>
#include <stdlib.h> 
#include "Debug.h"
#include "Main.h"
#include "Settings.h"
#include "Sandboxie.h"

static BOOL GetBool(LPCWSTR section, LPCWSTR key, BOOL defaultValue);
static int GetInt(LPCWSTR section, LPCWSTR key, int defaultValue);
static DWORD GetString(LPCWSTR section, LPCWSTR key, LPCWSTR defaultValue, LPWSTR outString, DWORD outSize);
static BOOL ExceptionExists(LPCWSTR section);
static BOOL SandboxExceptionExists(LPCWSTR section);

WCHAR SettingsIniPath[MAX_PATH];
WCHAR SandboxName[34];
WCHAR ProcessFileName[96];
WCHAR ProcessFilePath[MAX_PATH];
WCHAR StartRun_Exceptions[MAX_INI_KEY_LENGTH];
BOOL StartRun_RestrictionsEnabled = FALSE;
BOOL NoAdmin_HookShellExecute = FALSE;
BOOL NoAdmin_HookCheckTokenMembership = FALSE;
int Clipboard_Access = CLIPBOARD_ACCESS_READ_WRITE;

void SettingsLoad()
{
	GetModuleFileNameW(HModule_this, SettingsIniPath, MAX_PATH);
	PathRemoveFileSpecW(SettingsIniPath);
	wcscat_s(SettingsIniPath, MAX_PATH, L"\\SboxieUtil.ini");

	if (SbieApi_QueryProcess)
		SbieApi_QueryProcess(GetCurrentProcess(), SandboxName, ProcessFileName, NULL, NULL);

	GetModuleFileNameW(NULL, ProcessFilePath, MAX_PATH);

	DEBUGW_(L"Process '%s' started in '%s' (%s)", ProcessFileName, SandboxName, ProcessFilePath);

	if (!ExceptionExists(L"NoAdmin"))
	{
		NoAdmin_HookShellExecute = GetBool(L"NoAdmin", L"HookShellExecute", FALSE);
		NoAdmin_HookCheckTokenMembership = GetBool(L"NoAdmin", L"HookCheckTokenMembership", FALSE);
	}

	if (!ExceptionExists(L"Clipboard"))
		Clipboard_Access = GetInt(L"Clipboard", L"Access", CLIPBOARD_ACCESS_READ_WRITE);

	if (!SandboxExceptionExists(L"StartRun"))
	{
		StartRun_RestrictionsEnabled = GetBool(L"StartRun", L"RestrictionsEnabled", FALSE);
		GetString(L"StartRun", L"ProcessExceptions", L"", StartRun_Exceptions, MAX_INI_KEY_LENGTH);
	}
}

#pragma region Helper Functions

BOOL ListContains(LPCWSTR list, LPCWSTR item, LPCWSTR delimiter)
{
	if (!item || wcsnlen_s(item, MAX_PATH) == 0)
		return FALSE;

	WCHAR *tempList = (WCHAR *)malloc(MAX_INI_KEY_LENGTH * sizeof(WCHAR));
	if (tempList)
	{
		wcscpy_s(tempList, MAX_INI_KEY_LENGTH, list);

		WCHAR *buffer;
		WCHAR *token = wcstok_s(tempList, delimiter, &buffer);
		while (token)
		{
			if (_wcsicmp(token, item) == 0)
			{
				free(tempList);
				return TRUE;
			}
			token = wcstok_s(NULL, delimiter, &buffer);
		}
		free(tempList);
	}
	return FALSE;
}

static BOOL IniSectionExists(LPCWSTR section)
{
	WCHAR buf[4];
	return GetPrivateProfileSectionW(section, buf, sizeof(buf) / sizeof(WCHAR), SettingsIniPath) > 0;
}

static DWORD GetString(LPCWSTR section, LPCWSTR key, LPCWSTR defaultValue, LPWSTR outString, DWORD outSize)
{
	WCHAR newSection[MAX_INI_SECTION_LENGTH];
	
	swprintf_s(newSection, MAX_INI_SECTION_LENGTH, L"%s/%s:%s", section, SandboxName, ProcessFilePath);
	if (IniSectionExists(newSection))
		return GetPrivateProfileStringW(newSection, key, defaultValue, outString, outSize, SettingsIniPath);

	swprintf_s(newSection, MAX_INI_SECTION_LENGTH, L"%s/%s:%s", section, SandboxName, ProcessFileName);
	if (IniSectionExists(newSection))
		return GetPrivateProfileStringW(newSection, key, defaultValue, outString, outSize, SettingsIniPath);

	swprintf_s(newSection, MAX_INI_SECTION_LENGTH, L"%s/%s", section, SandboxName);
	if (IniSectionExists(newSection))
		return GetPrivateProfileStringW(newSection, key, defaultValue, outString, outSize, SettingsIniPath);

	swprintf_s(newSection, MAX_INI_SECTION_LENGTH, L"%s:%s", section, ProcessFilePath);
	if (IniSectionExists(newSection))
		return GetPrivateProfileStringW(newSection, key, defaultValue, outString, outSize, SettingsIniPath);

	swprintf_s(newSection, MAX_INI_SECTION_LENGTH, L"%s:%s", section, ProcessFileName);
	if (IniSectionExists(newSection))
		return GetPrivateProfileStringW(newSection, key, defaultValue, outString, outSize, SettingsIniPath);

	return GetPrivateProfileStringW(section, key, defaultValue, outString, outSize, SettingsIniPath);
}

static BOOL GetBool(LPCWSTR section, LPCWSTR key, BOOL defaultValue)
{
	WCHAR value[8];
	GetString(section, key, defaultValue ? L"Yes" : L"No", value, sizeof(value) / sizeof(WCHAR));
	return (_wcsicmp(value, L"yes") == 0 || _wcsicmp(value, L"true") == 0 || _wcsicmp(value, L"1") == 0);
}

static int GetInt(LPCWSTR section, LPCWSTR key, int defaultValue)
{
	WCHAR defvalue[16];
	swprintf_s(defvalue, sizeof(defvalue) / sizeof(WCHAR), L"%d", defaultValue);
	WCHAR value[16];
	GetString(section, key, defvalue, value, sizeof(value) / sizeof(WCHAR));
	return _wtoi(value);
}

static BOOL IniListContains(LPCWSTR iniSection, LPCWSTR iniKey, LPCWSTR item, LPCWSTR delimiter)
{
	WCHAR *exceptions = (WCHAR *)malloc(MAX_INI_KEY_LENGTH * sizeof(WCHAR));
	if (exceptions)
	{
		GetString(iniSection, iniKey, L"", exceptions, MAX_INI_KEY_LENGTH);
		BOOL result = ListContains(exceptions, item, delimiter);
		free(exceptions);
		return result;
	}
	return FALSE;
}

static BOOL SandboxExceptionExists(LPCWSTR section)
{
	return IniListContains(section, L"SandboxExceptions", SandboxName, L",");
}

static BOOL ProcessExceptionExists(LPCWSTR section)
{
	return IniListContains(section, L"ProcessExceptions", ProcessFileName, L",");
}

static BOOL ProcessPathExceptionExists(LPCWSTR section)
{
	return IniListContains(section, L"ProcessExceptions", ProcessFilePath, L",");
}

static BOOL ExceptionExists(LPCWSTR section)
{
	return ProcessExceptionExists(section) || ProcessPathExceptionExists(section) || SandboxExceptionExists(section);
}

#pragma endregion

