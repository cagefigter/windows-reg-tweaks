//SBIE DLL API - https://www.sandboxie.com/index.php?SBIE_DLL_API

#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

typedef LONG(__stdcall *SbieApi_EnumBoxes_)(LONG index, WCHAR *box_name);
typedef LONG(__stdcall *SbieApi_QueryBoxPath_)(
	const WCHAR *box_name, WCHAR *file_path, WCHAR *key_path, WCHAR *ipc_path, ULONG *file_path_len, 
	ULONG *key_path_len, ULONG *ipc_path_len);
typedef LONG(__stdcall *SbieApi_QueryProcessPath_)(
	HANDLE process_id, WCHAR *file_path, WCHAR *key_path, WCHAR *ipc_path, ULONG *file_path_len, 
	ULONG *key_path_len, ULONG *ipc_path_len);
typedef LONG(__stdcall *SbieApi_EnumProcessEx_)(
	const WCHAR *box_name, BOOLEAN all_sessions, ULONG which_session, ULONG *boxed_pids);
typedef LONG(__stdcall *SbieApi_QueryProcess_)(
	HANDLE process_id, WCHAR *box_name, WCHAR *image_name, WCHAR *sid_string, ULONG *session_id);
typedef BOOLEAN(__stdcall *SbieDll_KillOne_)(HANDLE process_id);
typedef BOOLEAN(__stdcall *SbieDll_KillAll_)(ULONG session_id, const WCHAR *box_name);
typedef LONG(__stdcall *SbieApi_QueryConf_)(
	const WCHAR *section_name, const WCHAR *setting_name, ULONG setting_index, WCHAR *value, ULONG value_len);
typedef LONG(__stdcall *SbieDll_UpdateConf_)(
	WCHAR operation_code, const WCHAR *password, const WCHAR *section_name, const WCHAR *setting_name, const WCHAR *value);
typedef LONG(__stdcall *SbieApi_ReloadConf_)(ULONG session_id);
typedef void *(__stdcall *SbieDll_Hook_)(const char *ApiName, void *ApiFunc, void *NewFunc);
typedef void(__stdcall *DllCallback)(const WCHAR *ImageName, HMODULE ImageBase);
typedef BOOLEAN *(__stdcall *SbieDll_RegisterDllCallback_)(DllCallback pCallback);
typedef LONG *(__stdcall *SbieApi_GetHomePath_)(WCHAR *NtPath, ULONG NtPathMaxLen, WCHAR *DosPath, ULONG DosPathMaxLen);

extern SbieApi_EnumBoxes_ SbieApi_EnumBoxes;
extern SbieApi_QueryBoxPath_ SbieApi_QueryBoxPath;
extern SbieApi_QueryProcessPath_ SbieApi_QueryProcessPath;
extern SbieApi_EnumProcessEx_ SbieApi_EnumProcessEx;
extern SbieApi_QueryProcess_ SbieApi_QueryProcess;
extern SbieDll_KillOne_ SbieDll_KillOne;
extern SbieDll_KillAll_ SbieDll_KillAll;
extern SbieApi_QueryConf_ SbieApi_QueryConf;
extern SbieDll_UpdateConf_ SbieDll_UpdateConf;
extern SbieApi_ReloadConf_ SbieApi_ReloadConf;
extern SbieDll_Hook_ SbieDll_Hook;
extern SbieDll_RegisterDllCallback_ SbieDll_RegisterDllCallback;
extern SbieApi_GetHomePath_ SbieApi_GetHomePath;
