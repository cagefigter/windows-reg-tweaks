#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "settings.h"

void DebugPrintA(const char *format, ...);
void DebugPrintW(const WCHAR *format, ...);

#ifdef UNICODE
#define DebugPrint  DebugPrintW
#else
#define DebugPrint  DebugPrintA
#endif // !UNICODE

#ifdef _DEBUG
#define WIDEN2(x) L ## x
#define WIDEN(x) WIDEN2(x)
#define __WFILE__ WIDEN(__FILE__)
#define __WFUNCTION__ WIDEN(__FUNCTION__)

#define DEBUGA_(format, ...) DebugPrintA( \
	"xDBG " format " [%s,%s,Line:%d]", __VA_ARGS__##, __FILE__, __FUNCTION__, __LINE__)

#define DEBUGW_(format, ...) DebugPrintW( \
	L"xDBG " format L" [%s,%s,Line:%d]", __VA_ARGS__##, __WFILE__, __WFUNCTION__, __LINE__)

#ifdef UNICODE
#define DEBUG_  DEBUGW_
#else
#define DEBUG_  DEBUGA_
#endif // !UNICODE

#else 
#define DEBUG_
#define DEBUGA_
#define DEBUGW_
#endif 

#define PUBLIC_DEBUG(format, ...) DebugPrintW( \
	L"xDBG SboxieUtil: " format L" [%s @ %s]", __VA_ARGS__##, ProcessFileName, SandboxName)
