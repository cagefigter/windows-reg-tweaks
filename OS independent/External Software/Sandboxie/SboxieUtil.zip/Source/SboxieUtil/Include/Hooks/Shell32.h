#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Shellapi.h>

typedef BOOL (WINAPI *RealShellExecuteExW_)(SHELLEXECUTEINFOW *pExecInfo);

BOOL WINAPI FakeShellExecuteExW(SHELLEXECUTEINFOW *pExecInfo);

extern RealShellExecuteExW_ RealShellExecuteExW;
