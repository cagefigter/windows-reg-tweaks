#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

typedef BOOL (WINAPI *RealCheckTokenMembership_)(HANDLE TokenHandle, PSID SidToCheck, PBOOL IsMember);

BOOL WINAPI FakeCheckTokenMembership(HANDLE TokenHandle, PSID SidToCheck, PBOOL IsMember);

extern RealCheckTokenMembership_ RealCheckTokenMembership;
