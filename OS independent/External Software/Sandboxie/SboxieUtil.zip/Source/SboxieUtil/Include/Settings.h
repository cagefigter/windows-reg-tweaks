#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define MAX_INI_KEY_LENGTH 4096
#define MAX_INI_SECTION_LENGTH 256
#define SANDBOXIE_EXECUTABLES L"SandboxieBITS.exe,SandboxieCrypto.exe,SandboxieDcomLaunch.exe,SandboxieWUAU.exe"

enum ClipboardAccess { 
	CLIPBOARD_ACCESS_READ_WRITE, 
	CLIPBOARD_ACCESS_READ,
	CLIPBOARD_ACCESS_WRITE,
	CLIPBOARD_ACCESS_BLOCK,
	CLIPBOARD_ACCESS_BLOCK_ALL
};

void SettingsLoad();
BOOL ListContains(LPCWSTR list, LPCWSTR item, LPCWSTR delimiter);

extern WCHAR SettingsIniPath[MAX_PATH];
extern WCHAR SandboxName[34];
extern WCHAR ProcessFileName[96];
extern WCHAR ProcessFilePath[MAX_PATH];
extern WCHAR StartRun_Exceptions[MAX_INI_KEY_LENGTH];
extern BOOL StartRun_RestrictionsEnabled;
extern BOOL NoAdmin_HookShellExecute;
extern BOOL NoAdmin_HookCheckTokenMembership;
extern int Clipboard_Access;
