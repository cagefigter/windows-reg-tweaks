##### SboxieUtil Features #####


1. Install programs without Administrator Rights (no UAC prompts, no SBIE2217 errors).
   -Tested with Inno Setup and NSIS installers, but it should work with other installers/programs too.

2. Clipboard access control for sandboxed programs (ReadWrite, Read, Write, Block, BlockAll).

3. Start/Run restrictions for programs installed -inside- of a sandbox.


Each feature supports exceptions "ProcessExceptions=" "SandboxExceptions=", configurable via SboxieUtil.ini


More features will be added later.



##### SboxieUtil Installation #####


1. Extract SboxieUtil.ini, SboxieUtil32.dll and SboxieUtil64.dll to a folder of your choice (e.g. C:\Program Files\Sandboxie\Plugins\)

2. Open Sandboxie Control, click on "Configure" then Edit Configuration.

3. Add SboxieUtil to the sandboxes of your choice:

----------------------

[DefaultBox]

InjectDll=C:\Program Files\Sandboxie\Plugins\SboxieUtil32.dll
InjectDll64=C:\Program Files\Sandboxie\Plugins\SboxieUtil64.dll

----------------------




##### Registy tweaks for the [NoAdmin] feature #####


SboxieUtil32.dll and SboxieUtil64.dll will take care of Inno Setup installers, however, some installers are set to run as Administrator via the application manifest file (you can tell that by the Shield Icon overlay on the installer executable).


There are multiple ways to prevent these UAC prompts:


### Method 1 ###

1. Add the following lines to your sandboxie Configuration:

----------------------

[DefaultBox]

AutoExec=REG ADD "HKCR\*\shell\forcerunasinvoker" /ve /f /d "Run without admin rights"
AutoExec=REG ADD "HKCR\*\shell\forcerunasinvoker\command" /ve /f /d "cmd /min /C \"set __COMPAT_LAYER=RUNASINVOKER && start \"\" \"%1\"\""

----------------------

2. Run a sandboxed Windows Explorer, browse to the installer executable and right click, select "Run without admin rights"


### Method 2 ###

1. Apply the registry tweak "RunSandboxedNoAdmin.reg" outside of your sandboxes.

2. Run a non-sandboxed Windows Explorer, browse to the installer executable and right click, select "Run Sandboxed (No Admin)"


### Method 3 ###

1. Apply the registry tweak "NoAdmin.reg" outside of your sandboxes.

2. Run a sandboxed Windows Explorer, browse to the installer executable and right click, select "Run without admin rights"


### Final words ###

A lot programs will install fine without Administrator Rights since sandboxie allows programs to write to HKEY_LOCAL_MACHINE without Administrator Rights. Installing programs into the ProgramFiles folder works too since we actually install into a fake folder within our sandbox.

However, some programs really need Administrator Rights to access services and other things, these programs will NOT work.



