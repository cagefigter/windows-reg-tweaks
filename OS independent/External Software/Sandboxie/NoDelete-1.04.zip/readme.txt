NoDelete is a DLL that prevents sandboxed programs from deleting any files in
the sandbox by silently "discarding" any delete operation and/or indicating a
successful delete in return. This is accomplished by hooking the following
Windows API functions:

From kernel32.dll:
- DeleteFile
- CreateFile
From ntdll.dll:
- NtDeleteFile
- NtSetInformationFile
From shell32.dll:
- SHFileOperation

This is similar to the andtidel.dll by Buster
(see http://www.sandboxie.com/phpbb/viewtopic.php?t=6764),
but this time it includes the 64-bit DLL.

Usage:
To use it, download the archive and extract the DLLs into some folder, for
example C:\Program Files\Sandboxie\plugins. Then insert this line in your
C:\Windows\Sandboxie.ini file for the sandbox in which you want to use the DLL:

InjectDll=C:\Program Files\Sandboxie\plugins\NoDelete32.dll

On x64 platforms, add the line for the 64-bit DLL:

InjectDll=C:\Program Files\Sandboxie\plugins\NoDelete32.dll
InjectDll64=C:\Program Files\Sandboxie\plugins\NoDelete64.dll

On x64 platforms, both DLLs and directives should be used. Sandboxie will inject
the proper DLL depending on whether the target process is 32-bit or 64-bit.

Full source of the plugin is included (released under MIT license).
