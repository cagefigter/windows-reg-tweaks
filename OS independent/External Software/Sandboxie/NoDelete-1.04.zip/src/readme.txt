How to compile
==============

Microsoft Visual Studio 10.0 32-bit compile:
--------------------------------------------
call "C:\Program Files\Microsoft Visual Studio 10.0\VC\bin\vcvars32.bat"
copy "C:\Program Files\Microsoft SDKs\Windows\v7.0A\Lib\User32.lib" User32.lib
rc NoDelete.rc
cl /D_USRDLL /D_WINDLL NoDelete.c NoDelete.res User32.lib /link /DLL /OUT:NoDelete32.dll


Microsoft Visual Studio 10.0 64-bit compile:
--------------------------------------------
call "C:\Program Files\Microsoft Visual Studio 10.0\VC\bin\x86_amd64\vcvarsx86_amd64.bat"
copy "C:\Program Files\Microsoft SDKs\Windows\v7.0A\Lib\x64\User32.lib" User64.lib
rc /D_WIN64 NoDelete.rc
cl /D_USRDLL /D_WINDLL NoDelete.c NoDelete.res User64.lib /link /DLL /OUT:NoDelete64.dll
