/*
Copyright (C) 2013 MiRo

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include <windows.h>
#include "NoDelete.h"

typedef void *(WINAPI *P_SbieDll_Hook)(const char *ApiName, void *ApiFunc, void *NewFunc);

typedef BOOL (WINAPI *P_DeleteFileA)(
  const CHAR *lpFileName);
typedef BOOL (WINAPI *P_DeleteFileW)(
  const WCHAR *lpFileName);
typedef HANDLE (WINAPI *P_CreateFileA)(
  const CHAR *lpFileName,
  const DWORD dwDesiredAccess,
  const DWORD dwShareMode,
  const SECURITY_ATTRIBUTES *lpSecurityAttributes,
  const DWORD dwCreationDisposition,
        DWORD dwFlagsAndAttributes,
  const HANDLE hTemplateFile);
typedef HANDLE (WINAPI *P_CreateFileW)(
  const WCHAR *lpFileName,
  const DWORD dwDesiredAccess,
  const DWORD dwShareMode,
  const SECURITY_ATTRIBUTES *lpSecurityAttributes,
  const DWORD dwCreationDisposition,
        DWORD dwFlagsAndAttributes,
  const HANDLE hTemplateFile);
typedef NTSTATUS (NTAPI *P_NtDeleteFile)(
  const OBJECT_ATTRIBUTES *pObjectAttributes);
typedef NTSTATUS (NTAPI *P_NtSetInformationFile)(
  const HANDLE FileHandle,
        IO_STATUS_BLOCK *IoStatusBlock,
  const VOID *FileInformation,
  const ULONG Length,
  const FILE_INFORMATION_CLASS FileInformationClass);
typedef int (WINAPI *P_SHFileOperation)(
  SHFILEOPSTRUCT *lpFileOp);

static P_DeleteFileA pDeleteFileA = NULL;
static P_DeleteFileW pDeleteFileW = NULL;
static P_CreateFileA pCreateFileA = NULL;
static P_CreateFileW pCreateFileW = NULL;
static P_NtDeleteFile pNtDeleteFile = NULL;
static P_NtSetInformationFile pNtSetInformationFile = NULL;
static P_SHFileOperation pSHFileOperation = NULL;

#define fDeleteFileA          0x01
#define fDeleteFileW          0x02
#define fCreateFileA          0x04
#define fCreateFileW          0x08
#define fNtDeleteFile         0x10
#define fNtSetInformationFile 0x20
#define fSHFileOperation      0x40

/*===========================================================================*/
static BOOL WINAPI MyDeleteFileA(
  const CHAR *lpFileName)
{
  // always return successfully deleted
  SetLastError(0);
  return TRUE;
} // MyDeleteFileA

/*===========================================================================*/
static BOOL WINAPI MyDeleteFileW(
  const WCHAR *lpFileName)
{
  // always return successfully deleted
  SetLastError(0);
  return TRUE;
} // MyDeleteFileW

/*===========================================================================*/
static HANDLE WINAPI MyCreateFileA(
  const CHAR *lpFileName,
  const DWORD dwDesiredAccess,
  const DWORD dwShareMode,
  const SECURITY_ATTRIBUTES *lpSecurityAttributes,
  const DWORD dwCreationDisposition,
        DWORD dwFlagsAndAttributes,
  const HANDLE hTemplateFile)
{
  // clear FILE_FLAG_DELETE_ON_CLOSE (0x04000000)
  dwFlagsAndAttributes &= 0xFBFFFFFF;
  return pCreateFileA(
    lpFileName,
    dwDesiredAccess,
    dwShareMode,
    lpSecurityAttributes,
    dwCreationDisposition,
    dwFlagsAndAttributes,
    hTemplateFile);
} // MyCreateFileA

/*===========================================================================*/
static HANDLE WINAPI MyCreateFileW(
  const WCHAR *lpFileName,
  const DWORD dwDesiredAccess,
  const DWORD dwShareMode,
  const SECURITY_ATTRIBUTES *lpSecurityAttributes,
  const DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes,
  const HANDLE hTemplateFile)
{
  // clear FILE_FLAG_DELETE_ON_CLOSE (0x04000000)
  dwFlagsAndAttributes &= 0xFBFFFFFF;
  return pCreateFileW(
    lpFileName,
    dwDesiredAccess,
    dwShareMode,
    lpSecurityAttributes,
    dwCreationDisposition,
    dwFlagsAndAttributes,
    hTemplateFile);
} // MyCreateFileW

static NTSTATUS NTAPI MyNtDeleteFile(
  const OBJECT_ATTRIBUTES *pObjectAttributes)
{
  // always return successfully deleted
  return STATUS_SUCCESS;
} // MyNtDeleteFile

/*===========================================================================*/
static NTSTATUS NTAPI MyNtSetInformationFile(
  const HANDLE FileHandle,
        IO_STATUS_BLOCK *IoStatusBlock,
        VOID *FileInformation,
  const ULONG Length,
  const FILE_INFORMATION_CLASS FileInformationClass)
{
  if (FileInformationClass == FileDispositionInformation) {
    if (FileInformation != NULL)
      // clear DeleteFile flag
      ((FILE_DISPOSITION_INFORMATION *)FileInformation)->DeleteFileFlag = FALSE;
  }
  return pNtSetInformationFile(
    FileHandle,
    IoStatusBlock,
    FileInformation,
    Length,
    FileInformationClass);
} // MyNtSetInformationFile

/*===========================================================================*/
static int WINAPI MySHFileOperation(
  SHFILEOPSTRUCT *lpFileOp)
{
  // ignore FO_DELETE function
  if (lpFileOp->wFunc == FO_DELETE) {
    SetLastError(0);
    return 0; // success
  }
  else
    return pSHFileOperation(lpFileOp);
} // MySHFileOperation

/*****************************************************************************/
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
  HMODULE SbieDll, Kernel32, NtDll, Shell32;
  P_SbieDll_Hook SbieDll_Hook;
  DWORD hooked;
  WCHAR *msg;

  if (dwReason == DLL_PROCESS_ATTACH) {
#if _DEBUG
#ifdef _WIN64
    MessageBoxW(NULL, L"Started 64-bit", L"InjectDll", MB_OK);
#else
    MessageBoxW(NULL, L"Started 32-bit", L"InjectDll", MB_OK);
#endif
#endif
    SbieDll = GetModuleHandleW(L"SbieDll.dll");

    if (SbieDll != NULL && SbieDll != INVALID_HANDLE_VALUE) {     
      SbieDll_Hook =
        (P_SbieDll_Hook)GetProcAddress(SbieDll, "SbieDll_Hook");

      if (SbieDll_Hook != NULL) {
        // remember which functions were hooked for debug message
        hooked = 0;

        // Hook kernel32.dll APIs
        Kernel32 = GetModuleHandleW(L"kernel32.dll");
        if (Kernel32 != NULL && Kernel32 != INVALID_HANDLE_VALUE) {
          pDeleteFileA =
            (P_DeleteFileA)GetProcAddress(Kernel32, "DeleteFileA");
          pDeleteFileW =
            (P_DeleteFileW)GetProcAddress(Kernel32, "DeleteFileW");
          pCreateFileA =
            (P_CreateFileA)GetProcAddress(Kernel32, "CreateFileA");
          pCreateFileW =
            (P_CreateFileW)GetProcAddress(Kernel32, "CreateFileW");

          if (pDeleteFileA != NULL) {
            pDeleteFileA = SbieDll_Hook("DeleteFileA", pDeleteFileA, MyDeleteFileA);
            if (pDeleteFileA != NULL) hooked |= fDeleteFileA;
          }
          if (pDeleteFileW != NULL) {
            pDeleteFileW = SbieDll_Hook("DeleteFileW", pDeleteFileW, MyDeleteFileW);
            if (pDeleteFileW != NULL) hooked |= fDeleteFileW;
          }
          if (pCreateFileA != NULL) {
            pCreateFileA = SbieDll_Hook("CreateFileA", pCreateFileA, MyCreateFileA);
            if (pCreateFileA != NULL) hooked |= fCreateFileA;
          }
          if (pCreateFileW != NULL) {
            pCreateFileW = SbieDll_Hook("CreateFileW", pCreateFileW, MyCreateFileW);
            if (pCreateFileW != NULL) hooked |= fCreateFileW;
          }
        } // if Kernel32

        // Hook ntdll.dll APIs
        NtDll = GetModuleHandleW(L"ntdll.dll");
        if (NtDll != NULL && NtDll != INVALID_HANDLE_VALUE) {
          pNtDeleteFile =
            (P_NtDeleteFile)GetProcAddress(NtDll, "NtDeleteFile");
          pNtSetInformationFile =
            (P_NtSetInformationFile)GetProcAddress(NtDll, "NtSetInformationFile");

          if (pNtDeleteFile != NULL) {
            pNtDeleteFile = SbieDll_Hook("NtDeleteFile", pNtDeleteFile, MyNtDeleteFile);
            if (pNtDeleteFile != NULL) hooked |= fNtDeleteFile;
          }
          if (pNtSetInformationFile != NULL) {
            pNtSetInformationFile = SbieDll_Hook("NtSetInformationFile", pNtSetInformationFile, MyNtSetInformationFile);
            if (pNtSetInformationFile != NULL) hooked |= fNtSetInformationFile;
          }
        } // if NtDll

        // Hook shell32.dll APIs
        Shell32 = GetModuleHandleW(L"shell32.dll");
        if (Shell32 == NULL || Shell32 == INVALID_HANDLE_VALUE)
          // load shell32.dll if not loaded
          Shell32 = LoadLibraryW(L"shell32.dll");
        if (Shell32 != NULL && Shell32 != INVALID_HANDLE_VALUE) {
          pSHFileOperation =
            (P_SHFileOperation)GetProcAddress(Shell32, "SHFileOperation");

          if (pSHFileOperation != NULL) {
            pSHFileOperation = SbieDll_Hook("SHFileOperation", pSHFileOperation, MySHFileOperation);
            if (pSHFileOperation != NULL) hooked |= fSHFileOperation;
          }
        } // if Shell32
#if _DEBUG
        msg = (WCHAR *)malloc(255*sizeof(WCHAR));
#ifdef _WIN64
        swprintf_s(msg, 255, L"Hooked %08X functions 64-bit", hooked);
#else
        swprintf_s(msg, 255, L"Hooked %08X functions 32-bit", hooked);
#endif
        MessageBoxW(NULL, msg, L"InjectDll", MB_OK);
#endif
      } // if ShieDll_Hook
    } // if SbieDll
  } // DLL_PROCESS_ATTACH

  return TRUE;
} // DllMain
