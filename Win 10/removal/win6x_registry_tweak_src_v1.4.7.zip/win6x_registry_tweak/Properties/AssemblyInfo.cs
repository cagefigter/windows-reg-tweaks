﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;
[assembly: ComVisible(false)]
[assembly: Guid("b0d40713-7d6f-427a-a79f-72d9ef92c6c8")]


[assembly: AssemblyTitleAttribute("win6.x_registry_tweak")]
[assembly: AssemblyDescriptionAttribute("Shows all packages in Windows Vista/7")]
[assembly: AssemblyCompanyAttribute("Modified by Legolash2o")]
[assembly: AssemblyProductAttribute("win6.x_registry_tweak")]
[assembly: AssemblyCopyrightAttribute("Copyright (c) 2008-2011 Michał Wnuowski")]
[assembly: AssemblyTrademarkAttribute("Michał Wnuowski")]
[assembly: AssemblyFileVersion("1.4.7.0")]
[assembly: NeutralResourcesLanguageAttribute("en-GB")]
[assembly: AssemblyVersion("1.4.7.0")]
